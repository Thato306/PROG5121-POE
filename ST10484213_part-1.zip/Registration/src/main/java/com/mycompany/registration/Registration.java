/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.registration;

import java.util.Scanner;

/**
 *
 * @author Student
 */
public class Registration {


    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.println("Welcome to the Registration and Login System");
        System.out.println("--------------------------------------------");
        
        // Get user details
        System.out.print("Enter your first name: ");
        String firstName = scanner.nextLine();
        
        System.out.print("Enter your last name: ");
        String lastName = scanner.nextLine();
        
        Login userLogin = new Login(firstName, lastName);
        
        // Registration process with validation loops
        System.out.println("\n--- Registration ---");
        
        // Validate username
        String username;
        while (true) {
            System.out.print("Enter username (must contain _ and be ≤5 chars): ");
            username = scanner.nextLine();
            if (userLogin.checkUserName(username)) {
                break;
            }
            System.out.println("Invalid username. It must contain an underscore '_' and be at most 5 characters long.");
        }
        
        // Validate password
        String password;
        while (true) {
            System.out.print("Enter password (min 8 chars, 1 capital, 1 number, 1 special char): ");
            password = scanner.nextLine();
            if (userLogin.checkPasswordComplexity(password)) {
                break;
            }
            System.out.println("Invalid password. It must be at least 8 characters, include 1 capital letter, 1 number, and 1 special character.");
        }
        
        // Validate cell number
        String cellNumber;
        while (true) {
            System.out.print("Enter South African cell number (with +27 international code): ");
            cellNumber = scanner.nextLine();
            if (userLogin.checkCellPhoneNumber(cellNumber)) {
                break;
            }
            System.out.println("Invalid cell number. Please use +27 followed by exactly 9 digits (e.g., +27123456789).");
        }
        
        // All inputs are valid, now register
        String registrationResult = userLogin.registerUser(username, password, cellNumber);
        System.out.println("\nRegistration Result:");
        System.out.println(registrationResult);
        
        // Login process
        if (registrationResult.contains("User registered successfully")) {
            System.out.println("\n--- Login ---");
            System.out.print("Enter username: ");
            String loginUsername = scanner.nextLine();
            
            System.out.print("Enter password: ");
            String loginPassword = scanner.nextLine();
            
            boolean loginStatus = userLogin.loginUser(loginUsername, loginPassword);
            System.out.println("\nLogin Status:");
            System.out.println(userLogin.returnLoginStatus(loginStatus));
        }
        
        scanner.close();
    }
}