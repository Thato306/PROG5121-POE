
package com.mycompany.registration;

import java.util.regex.Pattern;
class Login {
    
    private String username;
    private String password;
    private String firstName;
    private String lastName;
    private String cellNumber;

    public Login(String firstName, String lastName) {
        this.firstName = firstName;
        this.lastName = lastName;
    }

    public boolean checkUserName(String username) {
        return username.contains("_") && username.length() <= 5;
    }

    public boolean checkPasswordComplexity(String password) {
        String pattern = "^(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#$%^&*()_+\\-=\\[\\]{};':\"\\\\|,.<>\\/?]).{8,}$";
        return Pattern.matches(pattern, password);
    }

    public boolean checkCellPhoneNumber(String cellNumber) {
        String pattern = "^\\+27\\d{9}$";
        return Pattern.matches(pattern, cellNumber);
    }

    public String registerUser(String username, String password, String cellNumber) {
        boolean usernameValid = checkUserName(username);
        boolean passwordValid = checkPasswordComplexity(password);
        boolean cellNumberValid = checkCellPhoneNumber(cellNumber);

        if (!usernameValid) {
            return "Username is not correctly formatted, please ensure that your username contains an underscore and is no more than five characters in length.";
        }
        if (!passwordValid) {
            return "Password is not correctly formatted, please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.";
        }
        if (!cellNumberValid) {
            return "Cell phone number is incorrectly formatted or does not contain international code.";
        }

        this.username = username;
        this.password = password;
        this.cellNumber = cellNumber;

        return "Username successfully captured.\n" +
               "Password successfully captured.\n" +
               "Cell phone number successfully added.\n" +
               "User registered successfully!";
    }

    public boolean loginUser(String username, String password) {
        return username.equals(this.username) && password.equals(this.password);
    }

    public String returnLoginStatus(boolean loginStatus) {
        if (loginStatus) {
            return "Welcome " + firstName + "," + lastName + " it is great to see you again.";
        } else {
            return "Username or password incorrect, please try again.";
        }
    }

    public String getUsername() { return username; }
    public String getPassword() { return password; }
    public String getCellNumber() { return cellNumber; }
}